const C='sunrise-v13';
self.addEventListener('install',function(e){self.skipWaiting();});
self.addEventListener('activate',function(e){self.clients.claim();});
self.addEventListener('fetch',function(e){
  if(!e.request.url.startsWith('http'))return;
  e.respondWith(caches.open(C).then(function(c){
    return c.match(e.request).then(function(cached){
      var net=fetch(e.request).then(function(r){
        if(r.ok)c.put(e.request,r.clone());return r;
      }).catch(function(){return cached;});
      return cached||net;
    });
  }));
});